(self["webpackChunkyukoli_scaffold"] = self["webpackChunkyukoli_scaffold"] || []).push([[79],{

/***/ 162
() {

(function () {
  window.__inlineTranslations = {
    about_badge: "关于 YuKoLi",
    about_check_1: "自主研发，掌握核心配方",
    about_check_2: "严苛品控，HACCP/ISO双认证",
    about_cta_btn: "立即开启定制",
    about_hero_btn: "探索 YuKoLi 实力",
    about_hero_desc:
      "{brand} 扎根制造之都广东佛山，20+年深耕健康冲调饮品研发与制造。从OEM/ODM代工起步到8大产品线全品类覆盖，助力全球30+国家品牌实现降本增效与标准化出品",
    about_hero_title_1: "20+年深耕行业：",
    about_meta_title: "健康饮品OEM/ODM/OBM代工 | {{brand}}",
    about_stat_countries: "全球覆盖国家",
    about_stat_factories: "现代化智造基地",
    about_stat_founded: "年深耕行业",
    all: "全部",
    beauty: "美容胶原系列",
    btn_contact_us: "联系我们",
    case_detail_back: "返回案例列表",
    case_detail_cta_button: "联系 YuKoLi 团队",
    case_studies_count: "8个实战案例",
    cases_filter_benefit: "核心优势",
    cases_filter_industry: "业务场景",
    cases_filter_region: "地区",
    cases_filter_volume: "月订单量",
    cases_grid_title: "全部案例",
    cases_no_results: "未找到匹配案例，请尝试调整筛选条件。",
    cases_page_title: "{brand} | 健康食品 OEM/ODM 案例",
    cases_read_story: "查看详情",
    certifications: "认证资质",
    coffee: "咖啡系列",
    compliance_cta_sample: "免费索取合规样品",
    compliance_cta_title: "开启合规代工",
    compliance_cta_whatsapp: "WhatsApp 合规咨询",
    compliance_hero_title: "全球品质合规",
    compliance_section_title: "国际认证与合规体系",
    gut: "肠道健康",
    home_meta_title: "健康冲调饮品 OEM/ODM/OBM 代工专家 | YuKoLi",
    lifestyle: "功能冲饮",
    meal: "代餐系列",
    nav_about: "关于我们",
    nav_cases: "案例研究",
    nav_compliance: "合规认证",
    nav_contact: "联系",
    nav_faq: "常见问题",
    nav_get_quote: "获取报价",
    nav_home: "首页",
    nav_product_center: "产品中心",
    nav_products: "产品",
    nav_services: "服务",
    pdp_back: "返回",
    pdp_back_to_products: "返回产品中心",
    pdp_contact_sales: "联系销售",
    pdp_get_quote: "获取报价",
    pdp_need_custom_solution: "需要定制方案？",
    pdp_product_not_found: "产品未找到",
    pdp_product_specs: "产品规格",
    pdp_recommend_products: "推荐产品",
    pdp_site_suffix: "YuKoLi 健康冲调食品",
    pdp_tell_us_needs: "告诉我们您的需求，我们为您提供专属解决方案。",
    pdp_view_detail: "查看详情",
    products_compare_max_reached: "最多只能选择 {max} 款产品进行对比",
    tea: "茶饮系列",
    weight: "体重管理",
  };
})();


/***/ }

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ var __webpack_exports__ = (__webpack_exec__(162));
/******/ }
]);